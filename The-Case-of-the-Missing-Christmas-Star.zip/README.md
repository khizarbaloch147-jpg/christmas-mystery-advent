# The Case of the Missing Christmas Star

A 24-day Christmas mystery that plays in a browser, with the internet off. The download is one HTML file. There is nothing to install and no account to make.

## For the buyer

1. Unzip the folder.
2. Open `index.html` in a browser.
   - **Windows laptop or PC.** Double-click the file. It opens in Edge, Chrome, or Firefox.
   - **Mac.** Double-click the file. It opens in Safari.
   - **Android.** In Files or Downloads, tap `index.html` and open it with Chrome.
   - **iPhone or iPad.** In the Files app, tap `index.html` and open it in Safari. Come back in that same browser if you want your clues kept.
3. Pick a mode.
   - **Advent** opens door 1 on 1 December, door 2 on 2 December, and so on. After 24 December every door is open. Before December the doors stay shut.
   - **Binge** opens the next door as soon as the current puzzle is solved, on any date. Use this to play the whole case in one sitting, or if you start after Christmas.
4. Read the scene, solve the puzzle, and keep the clues in the notebook.
5. On door 24, name who took the star, why, and where it is hidden.

Progress stays in that browser. Settings has a sound switch and a reset. Reset asks before it clears the case.

Christmas in the story is 2026. That year is part of one puzzle, and it is printed on every screen.

The file is for the person who bought it, to play on their own laptop, tablet, or phone.

## What to upload

Zip `index.html` and this README together, and upload that zip as the digital file. Leave the solution out of the listing, the photos, and the preview.

The shop photos are in the `listing` folder. Each one is 2000 by 2000 pixels, the size Etsy recommends. Upload them in number order and use `01-cover.jpg` as the first image. Leave that folder out of the buyer zip.

Facts worth saying, in your own words:

- The download is instant and works offline.
- There is no account and no install.
- Advent mode is one door a day. Binge mode is the whole case in one sitting.
- It can be played again next Christmas.
- The pictures are drawn in the file. The sound is made by the browser.

If the marketplace asks how the game was made, say it was built with AI assistance.
